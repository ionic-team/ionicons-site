export declare const add: {
  ios: string;
  md: string;
};
export declare const addCircle: {
  ios: string;
  md: string;
};
export declare const addCircleOutline: {
  ios: string;
  md: string;
};
export declare const airplane: {
  ios: string;
  md: string;
};
export declare const alarm: {
  ios: string;
  md: string;
};
export declare const albums: {
  ios: string;
  md: string;
};
export declare const alert: {
  ios: string;
  md: string;
};
export declare const americanFootball: {
  ios: string;
  md: string;
};
export declare const analytics: {
  ios: string;
  md: string;
};
export declare const aperture: {
  ios: string;
  md: string;
};
export declare const apps: {
  ios: string;
  md: string;
};
export declare const appstore: {
  ios: string;
  md: string;
};
export declare const archive: {
  ios: string;
  md: string;
};
export declare const arrowBack: {
  ios: string;
  md: string;
};
export declare const arrowDown: {
  ios: string;
  md: string;
};
export declare const arrowDropdown: {
  ios: string;
  md: string;
};
export declare const arrowDropdownCircle: {
  ios: string;
  md: string;
};
export declare const arrowDropleft: {
  ios: string;
  md: string;
};
export declare const arrowDropleftCircle: {
  ios: string;
  md: string;
};
export declare const arrowDropright: {
  ios: string;
  md: string;
};
export declare const arrowDroprightCircle: {
  ios: string;
  md: string;
};
export declare const arrowDropup: {
  ios: string;
  md: string;
};
export declare const arrowDropupCircle: {
  ios: string;
  md: string;
};
export declare const arrowForward: {
  ios: string;
  md: string;
};
export declare const arrowRoundBack: {
  ios: string;
  md: string;
};
export declare const arrowRoundDown: {
  ios: string;
  md: string;
};
export declare const arrowRoundForward: {
  ios: string;
  md: string;
};
export declare const arrowRoundUp: {
  ios: string;
  md: string;
};
export declare const arrowUp: {
  ios: string;
  md: string;
};
export declare const at: {
  ios: string;
  md: string;
};
export declare const attach: {
  ios: string;
  md: string;
};
export declare const backspace: {
  ios: string;
  md: string;
};
export declare const barcode: {
  ios: string;
  md: string;
};
export declare const baseball: {
  ios: string;
  md: string;
};
export declare const basket: {
  ios: string;
  md: string;
};
export declare const basketball: {
  ios: string;
  md: string;
};
export declare const batteryCharging: {
  ios: string;
  md: string;
};
export declare const batteryDead: {
  ios: string;
  md: string;
};
export declare const batteryFull: {
  ios: string;
  md: string;
};
export declare const beaker: {
  ios: string;
  md: string;
};
export declare const bed: {
  ios: string;
  md: string;
};
export declare const beer: {
  ios: string;
  md: string;
};
export declare const bicycle: {
  ios: string;
  md: string;
};
export declare const bluetooth: {
  ios: string;
  md: string;
};
export declare const boat: {
  ios: string;
  md: string;
};
export declare const body: {
  ios: string;
  md: string;
};
export declare const bonfire: {
  ios: string;
  md: string;
};
export declare const book: {
  ios: string;
  md: string;
};
export declare const bookmark: {
  ios: string;
  md: string;
};
export declare const bookmarks: {
  ios: string;
  md: string;
};
export declare const bowtie: {
  ios: string;
  md: string;
};
export declare const briefcase: {
  ios: string;
  md: string;
};
export declare const browsers: {
  ios: string;
  md: string;
};
export declare const brush: {
  ios: string;
  md: string;
};
export declare const bug: {
  ios: string;
  md: string;
};
export declare const build: {
  ios: string;
  md: string;
};
export declare const bulb: {
  ios: string;
  md: string;
};
export declare const bus: {
  ios: string;
  md: string;
};
export declare const business: {
  ios: string;
  md: string;
};
export declare const cafe: {
  ios: string;
  md: string;
};
export declare const calculator: {
  ios: string;
  md: string;
};
export declare const calendar: {
  ios: string;
  md: string;
};
export declare const call: {
  ios: string;
  md: string;
};
export declare const camera: {
  ios: string;
  md: string;
};
export declare const car: {
  ios: string;
  md: string;
};
export declare const card: {
  ios: string;
  md: string;
};
export declare const cart: {
  ios: string;
  md: string;
};
export declare const cash: {
  ios: string;
  md: string;
};
export declare const cellular: {
  ios: string;
  md: string;
};
export declare const chatboxes: {
  ios: string;
  md: string;
};
export declare const chatbubbles: {
  ios: string;
  md: string;
};
export declare const checkbox: {
  ios: string;
  md: string;
};
export declare const checkboxOutline: {
  ios: string;
  md: string;
};
export declare const checkmark: {
  ios: string;
  md: string;
};
export declare const checkmarkCircle: {
  ios: string;
  md: string;
};
export declare const checkmarkCircleOutline: {
  ios: string;
  md: string;
};
export declare const clipboard: {
  ios: string;
  md: string;
};
export declare const clock: {
  ios: string;
  md: string;
};
export declare const close: {
  ios: string;
  md: string;
};
export declare const closeCircle: {
  ios: string;
  md: string;
};
export declare const closeCircleOutline: {
  ios: string;
  md: string;
};
export declare const cloud: {
  ios: string;
  md: string;
};
export declare const cloudCircle: {
  ios: string;
  md: string;
};
export declare const cloudDone: {
  ios: string;
  md: string;
};
export declare const cloudDownload: {
  ios: string;
  md: string;
};
export declare const cloudOutline: {
  ios: string;
  md: string;
};
export declare const cloudUpload: {
  ios: string;
  md: string;
};
export declare const cloudy: {
  ios: string;
  md: string;
};
export declare const cloudyNight: {
  ios: string;
  md: string;
};
export declare const code: {
  ios: string;
  md: string;
};
export declare const codeDownload: {
  ios: string;
  md: string;
};
export declare const codeWorking: {
  ios: string;
  md: string;
};
export declare const cog: {
  ios: string;
  md: string;
};
export declare const colorFill: {
  ios: string;
  md: string;
};
export declare const colorFilter: {
  ios: string;
  md: string;
};
export declare const colorPalette: {
  ios: string;
  md: string;
};
export declare const colorWand: {
  ios: string;
  md: string;
};
export declare const compass: {
  ios: string;
  md: string;
};
export declare const construct: {
  ios: string;
  md: string;
};
export declare const contact: {
  ios: string;
  md: string;
};
export declare const contacts: {
  ios: string;
  md: string;
};
export declare const contract: {
  ios: string;
  md: string;
};
export declare const contrast: {
  ios: string;
  md: string;
};
export declare const copy: {
  ios: string;
  md: string;
};
export declare const create: {
  ios: string;
  md: string;
};
export declare const crop: {
  ios: string;
  md: string;
};
export declare const cube: {
  ios: string;
  md: string;
};
export declare const cut: {
  ios: string;
  md: string;
};
export declare const desktop: {
  ios: string;
  md: string;
};
export declare const disc: {
  ios: string;
  md: string;
};
export declare const document: {
  ios: string;
  md: string;
};
export declare const doneAll: {
  ios: string;
  md: string;
};
export declare const download: {
  ios: string;
  md: string;
};
export declare const easel: {
  ios: string;
  md: string;
};
export declare const egg: {
  ios: string;
  md: string;
};
export declare const exit: {
  ios: string;
  md: string;
};
export declare const expand: {
  ios: string;
  md: string;
};
export declare const eye: {
  ios: string;
  md: string;
};
export declare const eyeOff: {
  ios: string;
  md: string;
};
export declare const fastforward: {
  ios: string;
  md: string;
};
export declare const female: {
  ios: string;
  md: string;
};
export declare const filing: {
  ios: string;
  md: string;
};
export declare const film: {
  ios: string;
  md: string;
};
export declare const fingerPrint: {
  ios: string;
  md: string;
};
export declare const fitness: {
  ios: string;
  md: string;
};
export declare const flag: {
  ios: string;
  md: string;
};
export declare const flame: {
  ios: string;
  md: string;
};
export declare const flash: {
  ios: string;
  md: string;
};
export declare const flashOff: {
  ios: string;
  md: string;
};
export declare const flashlight: {
  ios: string;
  md: string;
};
export declare const flask: {
  ios: string;
  md: string;
};
export declare const flower: {
  ios: string;
  md: string;
};
export declare const folder: {
  ios: string;
  md: string;
};
export declare const folderOpen: {
  ios: string;
  md: string;
};
export declare const football: {
  ios: string;
  md: string;
};
export declare const funnel: {
  ios: string;
  md: string;
};
export declare const gift: {
  ios: string;
  md: string;
};
export declare const gitBranch: {
  ios: string;
  md: string;
};
export declare const gitCommit: {
  ios: string;
  md: string;
};
export declare const gitCompare: {
  ios: string;
  md: string;
};
export declare const gitMerge: {
  ios: string;
  md: string;
};
export declare const gitNetwork: {
  ios: string;
  md: string;
};
export declare const gitPullRequest: {
  ios: string;
  md: string;
};
export declare const glasses: {
  ios: string;
  md: string;
};
export declare const globe: {
  ios: string;
  md: string;
};
export declare const grid: {
  ios: string;
  md: string;
};
export declare const hammer: {
  ios: string;
  md: string;
};
export declare const hand: {
  ios: string;
  md: string;
};
export declare const happy: {
  ios: string;
  md: string;
};
export declare const headset: {
  ios: string;
  md: string;
};
export declare const heart: {
  ios: string;
  md: string;
};
export declare const heartDislike: {
  ios: string;
  md: string;
};
export declare const heartEmpty: {
  ios: string;
  md: string;
};
export declare const heartHalf: {
  ios: string;
  md: string;
};
export declare const help: {
  ios: string;
  md: string;
};
export declare const helpBuoy: {
  ios: string;
  md: string;
};
export declare const helpCircle: {
  ios: string;
  md: string;
};
export declare const helpCircleOutline: {
  ios: string;
  md: string;
};
export declare const home: {
  ios: string;
  md: string;
};
export declare const hourglass: {
  ios: string;
  md: string;
};
export declare const iceCream: {
  ios: string;
  md: string;
};
export declare const image: {
  ios: string;
  md: string;
};
export declare const images: {
  ios: string;
  md: string;
};
export declare const infinite: {
  ios: string;
  md: string;
};
export declare const information: {
  ios: string;
  md: string;
};
export declare const informationCircle: {
  ios: string;
  md: string;
};
export declare const informationCircleOutline: {
  ios: string;
  md: string;
};
export declare const jet: {
  ios: string;
  md: string;
};
export declare const journal: {
  ios: string;
  md: string;
};
export declare const key: {
  ios: string;
  md: string;
};
export declare const keypad: {
  ios: string;
  md: string;
};
export declare const laptop: {
  ios: string;
  md: string;
};
export declare const leaf: {
  ios: string;
  md: string;
};
export declare const link: {
  ios: string;
  md: string;
};
export declare const list: {
  ios: string;
  md: string;
};
export declare const listBox: {
  ios: string;
  md: string;
};
export declare const locate: {
  ios: string;
  md: string;
};
export declare const lock: {
  ios: string;
  md: string;
};
export declare const logIn: {
  ios: string;
  md: string;
};
export declare const logOut: {
  ios: string;
  md: string;
};
export declare const logoAndroid: string;
export declare const logoAngular: string;
export declare const logoApple: string;
export declare const logoBitbucket: string;
export declare const logoBitcoin: string;
export declare const logoBuffer: string;
export declare const logoChrome: string;
export declare const logoClosedCaptioning: string;
export declare const logoCodepen: string;
export declare const logoCss3: string;
export declare const logoDesignernews: string;
export declare const logoDribbble: string;
export declare const logoDropbox: string;
export declare const logoEuro: string;
export declare const logoFacebook: string;
export declare const logoFlickr: string;
export declare const logoFoursquare: string;
export declare const logoFreebsdDevil: string;
export declare const logoGameControllerA: string;
export declare const logoGameControllerB: string;
export declare const logoGithub: string;
export declare const logoGoogle: string;
export declare const logoGoogleplus: string;
export declare const logoHackernews: string;
export declare const logoHtml5: string;
export declare const logoInstagram: string;
export declare const logoIonic: string;
export declare const logoIonitron: string;
export declare const logoJavascript: string;
export declare const logoLinkedin: string;
export declare const logoMarkdown: string;
export declare const logoModelS: string;
export declare const logoNoSmoking: string;
export declare const logoNodejs: string;
export declare const logoNpm: string;
export declare const logoOctocat: string;
export declare const logoPinterest: string;
export declare const logoPlaystation: string;
export declare const logoPolymer: string;
export declare const logoPython: string;
export declare const logoReddit: string;
export declare const logoRss: string;
export declare const logoSass: string;
export declare const logoSkype: string;
export declare const logoSlack: string;
export declare const logoSnapchat: string;
export declare const logoSteam: string;
export declare const logoTumblr: string;
export declare const logoTux: string;
export declare const logoTwitch: string;
export declare const logoTwitter: string;
export declare const logoUsd: string;
export declare const logoVimeo: string;
export declare const logoVk: string;
export declare const logoWhatsapp: string;
export declare const logoWindows: string;
export declare const logoWordpress: string;
export declare const logoXbox: string;
export declare const logoXing: string;
export declare const logoYahoo: string;
export declare const logoYen: string;
export declare const logoYoutube: string;
export declare const magnet: {
  ios: string;
  md: string;
};
export declare const mail: {
  ios: string;
  md: string;
};
export declare const mailOpen: {
  ios: string;
  md: string;
};
export declare const mailUnread: {
  ios: string;
  md: string;
};
export declare const male: {
  ios: string;
  md: string;
};
export declare const man: {
  ios: string;
  md: string;
};
export declare const map: {
  ios: string;
  md: string;
};
export declare const medal: {
  ios: string;
  md: string;
};
export declare const medical: {
  ios: string;
  md: string;
};
export declare const medkit: {
  ios: string;
  md: string;
};
export declare const megaphone: {
  ios: string;
  md: string;
};
export declare const menu: {
  ios: string;
  md: string;
};
export declare const mic: {
  ios: string;
  md: string;
};
export declare const micOff: {
  ios: string;
  md: string;
};
export declare const microphone: {
  ios: string;
  md: string;
};
export declare const moon: {
  ios: string;
  md: string;
};
export declare const more: {
  ios: string;
  md: string;
};
export declare const move: {
  ios: string;
  md: string;
};
export declare const musicalNote: {
  ios: string;
  md: string;
};
export declare const musicalNotes: {
  ios: string;
  md: string;
};
export declare const navigate: {
  ios: string;
  md: string;
};
export declare const notifications: {
  ios: string;
  md: string;
};
export declare const notificationsOff: {
  ios: string;
  md: string;
};
export declare const notificationsOutline: {
  ios: string;
  md: string;
};
export declare const nuclear: {
  ios: string;
  md: string;
};
export declare const nutrition: {
  ios: string;
  md: string;
};
export declare const open: {
  ios: string;
  md: string;
};
export declare const options: {
  ios: string;
  md: string;
};
export declare const outlet: {
  ios: string;
  md: string;
};
export declare const paper: {
  ios: string;
  md: string;
};
export declare const paperPlane: {
  ios: string;
  md: string;
};
export declare const partlySunny: {
  ios: string;
  md: string;
};
export declare const pause: {
  ios: string;
  md: string;
};
export declare const paw: {
  ios: string;
  md: string;
};
export declare const people: {
  ios: string;
  md: string;
};
export declare const person: {
  ios: string;
  md: string;
};
export declare const personAdd: {
  ios: string;
  md: string;
};
export declare const phoneLandscape: {
  ios: string;
  md: string;
};
export declare const phonePortrait: {
  ios: string;
  md: string;
};
export declare const photos: {
  ios: string;
  md: string;
};
export declare const pie: {
  ios: string;
  md: string;
};
export declare const pin: {
  ios: string;
  md: string;
};
export declare const pint: {
  ios: string;
  md: string;
};
export declare const pizza: {
  ios: string;
  md: string;
};
export declare const planet: {
  ios: string;
  md: string;
};
export declare const play: {
  ios: string;
  md: string;
};
export declare const playCircle: {
  ios: string;
  md: string;
};
export declare const podium: {
  ios: string;
  md: string;
};
export declare const power: {
  ios: string;
  md: string;
};
export declare const pricetag: {
  ios: string;
  md: string;
};
export declare const pricetags: {
  ios: string;
  md: string;
};
export declare const print: {
  ios: string;
  md: string;
};
export declare const pulse: {
  ios: string;
  md: string;
};
export declare const qrScanner: {
  ios: string;
  md: string;
};
export declare const quote: {
  ios: string;
  md: string;
};
export declare const radio: {
  ios: string;
  md: string;
};
export declare const radioButtonOff: {
  ios: string;
  md: string;
};
export declare const radioButtonOn: {
  ios: string;
  md: string;
};
export declare const rainy: {
  ios: string;
  md: string;
};
export declare const recording: {
  ios: string;
  md: string;
};
export declare const redo: {
  ios: string;
  md: string;
};
export declare const refresh: {
  ios: string;
  md: string;
};
export declare const refreshCircle: {
  ios: string;
  md: string;
};
export declare const remove: {
  ios: string;
  md: string;
};
export declare const removeCircle: {
  ios: string;
  md: string;
};
export declare const removeCircleOutline: {
  ios: string;
  md: string;
};
export declare const reorder: {
  ios: string;
  md: string;
};
export declare const repeat: {
  ios: string;
  md: string;
};
export declare const resize: {
  ios: string;
  md: string;
};
export declare const restaurant: {
  ios: string;
  md: string;
};
export declare const returnLeft: {
  ios: string;
  md: string;
};
export declare const returnRight: {
  ios: string;
  md: string;
};
export declare const reverseCamera: {
  ios: string;
  md: string;
};
export declare const rewind: {
  ios: string;
  md: string;
};
export declare const ribbon: {
  ios: string;
  md: string;
};
export declare const rocket: {
  ios: string;
  md: string;
};
export declare const rose: {
  ios: string;
  md: string;
};
export declare const sad: {
  ios: string;
  md: string;
};
export declare const save: {
  ios: string;
  md: string;
};
export declare const school: {
  ios: string;
  md: string;
};
export declare const search: {
  ios: string;
  md: string;
};
export declare const send: {
  ios: string;
  md: string;
};
export declare const settings: {
  ios: string;
  md: string;
};
export declare const share: {
  ios: string;
  md: string;
};
export declare const shareAlt: {
  ios: string;
  md: string;
};
export declare const shirt: {
  ios: string;
  md: string;
};
export declare const shuffle: {
  ios: string;
  md: string;
};
export declare const skipBackward: {
  ios: string;
  md: string;
};
export declare const skipForward: {
  ios: string;
  md: string;
};
export declare const snow: {
  ios: string;
  md: string;
};
export declare const speedometer: {
  ios: string;
  md: string;
};
export declare const square: {
  ios: string;
  md: string;
};
export declare const squareOutline: {
  ios: string;
  md: string;
};
export declare const star: {
  ios: string;
  md: string;
};
export declare const starHalf: {
  ios: string;
  md: string;
};
export declare const starOutline: {
  ios: string;
  md: string;
};
export declare const stats: {
  ios: string;
  md: string;
};
export declare const stopwatch: {
  ios: string;
  md: string;
};
export declare const subway: {
  ios: string;
  md: string;
};
export declare const sunny: {
  ios: string;
  md: string;
};
export declare const swap: {
  ios: string;
  md: string;
};
export declare const switcher: {
  ios: string;
  md: string;
};
export declare const sync: {
  ios: string;
  md: string;
};
export declare const tabletLandscape: {
  ios: string;
  md: string;
};
export declare const tabletPortrait: {
  ios: string;
  md: string;
};
export declare const tennisball: {
  ios: string;
  md: string;
};
export declare const text: {
  ios: string;
  md: string;
};
export declare const thermometer: {
  ios: string;
  md: string;
};
export declare const thumbsDown: {
  ios: string;
  md: string;
};
export declare const thumbsUp: {
  ios: string;
  md: string;
};
export declare const thunderstorm: {
  ios: string;
  md: string;
};
export declare const time: {
  ios: string;
  md: string;
};
export declare const timer: {
  ios: string;
  md: string;
};
export declare const today: {
  ios: string;
  md: string;
};
export declare const train: {
  ios: string;
  md: string;
};
export declare const transgender: {
  ios: string;
  md: string;
};
export declare const trash: {
  ios: string;
  md: string;
};
export declare const trendingDown: {
  ios: string;
  md: string;
};
export declare const trendingUp: {
  ios: string;
  md: string;
};
export declare const trophy: {
  ios: string;
  md: string;
};
export declare const tv: {
  ios: string;
  md: string;
};
export declare const umbrella: {
  ios: string;
  md: string;
};
export declare const undo: {
  ios: string;
  md: string;
};
export declare const unlock: {
  ios: string;
  md: string;
};
export declare const videocam: {
  ios: string;
  md: string;
};
export declare const volumeHigh: {
  ios: string;
  md: string;
};
export declare const volumeLow: {
  ios: string;
  md: string;
};
export declare const volumeMute: {
  ios: string;
  md: string;
};
export declare const volumeOff: {
  ios: string;
  md: string;
};
export declare const walk: {
  ios: string;
  md: string;
};
export declare const wallet: {
  ios: string;
  md: string;
};
export declare const warning: {
  ios: string;
  md: string;
};
export declare const watch: {
  ios: string;
  md: string;
};
export declare const water: {
  ios: string;
  md: string;
};
export declare const wifi: {
  ios: string;
  md: string;
};
export declare const wine: {
  ios: string;
  md: string;
};
export declare const woman: {
  ios: string;
  md: string;
};
